import UIKit

func FinalEquation(_ a: Int, _ b: Int) -> Int {
    return a + b
}
print("Final Result: \(FinalEquation(24,22))")
